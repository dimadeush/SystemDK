<?php
if (preg_match("/menu.php/i", $_SERVER['PHP_SELF']))
 {
    Header("Location: ../../index.php");
    exit();
 }


$sql = "SELECT a.mainmenu_type,a.mainmenu_name,a.mainmenu_module,a.mainmenu_submodule,a.mainmenu_target,(SELECT max(b.module_valueview) FROM ".$GLOBALS['prefix']."_modules_".$GLOBALS['sitelang']." b WHERE (a.mainmenu_module is not NULL AND b.module_name=a.mainmenu_module OR a.mainmenu_submodule is not NULL AND b.module_name=a.mainmenu_submodule) AND b.module_status='1' AND a.mainmenu_type='module') as module_valueview, (SELECT max(c.mainpage_valueview) FROM ".$GLOBALS['prefix']."_main_pages_".$GLOBALS['sitelang']." c WHERE (a.mainmenu_module is not NULL AND c.mainpage_id=a.mainmenu_module OR a.mainmenu_submodule is not NULL AND c.mainpage_id=a.mainmenu_submodule) AND c.mainpage_status='1' AND a.mainmenu_type='main_page') as mainpage_valueview,a.mainmenu_id FROM ".$GLOBALS['prefix']."_main_menu_".$GLOBALS['sitelang']." a WHERE a.mainmenu_inmenu='1' ORDER BY a.mainmenu_priority";
$result = $GLOBALS['adodb']->Execute($sql);
if($result)
 {
   if(isset($result->fields['7']))
    {
      $numrows = intval($result->fields['7']);
    }
   else 
    {
      $numrows = 0;
    }
 }
if(isset($numrows) and $numrows > 0)
 {
   while(!$result->EOF)
    {
      $mainmenu_type = $GLOBALS['mainfunc']->extracting_data($result->fields['0']);
      $mainmenu_name = $GLOBALS['mainfunc']->extracting_data($result->fields['1']);
      $mainmenu_module = $GLOBALS['mainfunc']->extracting_data($result->fields['2']);
      $mainmenu_submodule = $GLOBALS['mainfunc']->extracting_data($result->fields['3']);
      $mainmenu_target = $GLOBALS['mainfunc']->extracting_data($result->fields['4']);
      if(!isset($mainmenu_module) or $mainmenu_module == "")
       {
         $mainmenu_element = $mainmenu_submodule;
         $mainmenu_element_type = "child";
       }
      elseif(!isset($mainmenu_submodule) or $mainmenu_submodule == "")
       {
         $mainmenu_element = $mainmenu_module;
         $mainmenu_element_type = "parent";
       }
      if($mainmenu_type != "other")
       {
         if($mainmenu_type == "module")
          {
            if(isset($result->fields['5']) and $GLOBALS['mainfunc']->extracting_data($result->fields['5']) != "")
             {
               $numrows2 = 1;
               $valueview = intval($result->fields['5']);
             }
          }
         elseif($mainmenu_type == "main_page")
          {
            if(isset($result->fields['6']) and $GLOBALS['mainfunc']->extracting_data($result->fields['6']) != "")
             {
               $numrows2 = 1;
               $valueview = intval($result->fields['6']);
             }
          }
         if(isset($numrows2) and $numrows2 > 0)
          {
            if($valueview == "0")
             {
               $display_access = "yes";
             }
            elseif($valueview == "1" and ($GLOBALS['mainfunc']->is_user_in_mainfunc() or $GLOBALS['mainfunc']->is_admin_in_mainfunc()))
             {
               $display_access = "yes";
             }
            elseif($valueview == "2" and $GLOBALS['mainfunc']->is_admin_in_mainfunc())
             {
               $display_access = "yes";
             }
            elseif($valueview == "3" and (!$GLOBALS['mainfunc']->is_user_in_mainfunc() or $GLOBALS['mainfunc']->is_admin_in_mainfunc()))
             {
               $display_access = "yes";
             }
            else
             {
               $display_access = "no";
             }
          }
         else 
          {
            $display_access = "no";
          }
       }
      elseif($mainmenu_type == "other")
       {
         $display_access = "yes";
       }
      else 
       {
         $display_access = "no";
       }
      $block_content_array[] = array("mainmenu_type"=>$mainmenu_type, "mainmenu_name"=>$mainmenu_name, "mainmenu_element"=>$mainmenu_element, "mainmenu_element_type"=>$mainmenu_element_type, "mainmenu_target"=>$mainmenu_target, "display_access"=>$display_access);
      $result->MoveNext();
    }
   $GLOBALS['smarty']->assign("block_content_array",$block_content_array);
 }
else
 {
   $GLOBALS['smarty']->assign("block_content_array","no");
 }
$block_content = $GLOBALS['smarty']->fetch("blocks/menu/menu.html");

?>