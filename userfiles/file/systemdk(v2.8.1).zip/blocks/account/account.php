<?php
if (preg_match("/account.php/i", $_SERVER['PHP_SELF']))
 {
    Header("Location: ../../index.php");
    exit();
 }

if($GLOBALS['mainfunc']->is_user_in_mainfunc())
 {
   $row = $GLOBALS['mainfunc']->get_user_info($GLOBALS['user']);
   if(isset($row) and $row != "")
    {
      $user_name = $GLOBALS['mainfunc']->format_htmlspecchars($GLOBALS['mainfunc']->extracting_data($row['1']));
      $user_surname = $GLOBALS['mainfunc']->format_htmlspecchars($GLOBALS['mainfunc']->extracting_data($row['2']));
      if((!isset($user_name) or $user_name == "") and (isset($user_surname) and $user_surname != ""))
       {
          $block_account_username = $user_surname;
       }
      elseif((!isset($user_name) or $user_name == "") and (!isset($user_surname) or $user_surname == ""))
       {
         $block_account_username = $GLOBALS['mainfunc']->extracting_data($row['5']);
       }
      elseif((isset($user_name) or $user_name != "") and (isset($user_surname) or $user_surname != ""))
       {
         $block_account_username = $user_name." ".$user_surname;
       }
    }
   else 
    {
      $block_account_username = "no";
    }
   $GLOBALS['smarty']->assign("block_content_array",$block_account_username);
 }
else 
 {
   $GLOBALS['smarty']->assign("block_content_array","no");
 }
$block_content = $GLOBALS['smarty']->fetch("blocks/account/account.html");

?>