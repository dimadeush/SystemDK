<?php
$stat = array (
  0 => 
  array (
    'type' => 'CACHE_CLEAR_STATISTIC',
    'date' => 1309378153,
    'remote_addr' => '127.0.0.1',
  ),
);