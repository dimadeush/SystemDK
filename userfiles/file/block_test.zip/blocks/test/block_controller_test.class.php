<?php


/**
 * Project:   SystemDK: PHP Content Management System
 * File:      block_controller_test.class.php
 *
 * @link      http://www.systemsdk.com/
 * @copyright 2014 SystemDK
 * @author    Dmitriy Kravtsov <admin@systemsdk.com>
 * @package   SystemDK
 * @version   3.1
 */
class block_controller_test extends controller_base {


    private $model_block_test;


    public function __construct($registry) {
        parent::__construct($registry);
        $this->model_block_test = singleton::getinstance('block_test',$registry);
    }


    public function index() {
        $block_content_array = $this->model_block_test->index();
        $this->assign_array($block_content_array);
        return $block_content = $this->fetch("blocks/test/test.html"); //this function is obligatory for every block. You just need to fill path to template. In our case it is blocks/test/test.html
    }
}