<?php
/**
 * Project:   SystemDK: PHP Content Management System
 * File:      test.class.php
 *
 * @link      http://www.systemsdk.com/
 * @copyright 2013 SystemDK
 * @author    Dmitriy Kravtsov <admin@systemsdk.com>
 * @package   SystemDK
 * @version   3.0
 */
class block_test_model extends model_base {


    public function index() {
        if($this->registry->main_class->is_user_in_mainfunc()) { //this function is using for checking if it is user or not
            $row = $this->registry->main_class->get_user_info($this->registry->user); // this function returns user data in array.
            if(isset($row) and $row != "") {
                $user_name = $this->registry->main_class->format_htmlspecchars($this->registry->main_class->extracting_data($row['1'])); // equal to htmlspecialchars(stripslashes(trim($row['1'])));
                $user_surname = $this->registry->main_class->format_htmlspecchars($this->registry->main_class->extracting_data($row['2'])); // equal to htmlspecialchars(stripslashes(trim($row['2'])));
                if((!isset($user_name) or $user_name == "") and (isset($user_surname) and $user_surname != "")) {
                    $block_account_username = $user_surname;
                } elseif((!isset($user_name) or $user_name == "") and (!isset($user_surname) or $user_surname == "")) {
                    $block_account_username = $this->registry->main_class->extracting_data($row['5']); // equal to stripslashes(trim($row['1']));
                } elseif((isset($user_name) or $user_name != "") and (isset($user_surname) or $user_surname != "")) {
                    $block_account_username = $user_name." ".$user_surname;
                }
            } else {
                $block_account_username = "no";
            }
        } else {
            $block_account_username = "no";
        }
        $this->registry->main_class->assign("block_content_array",$block_account_username);
         return $block_content = $this->registry->main_class->fetch("blocks/test/test.html"); //this function is obligatory for every block. You just need to fill path to template. In our case it is blocks/test/test.html
    }
}

?>