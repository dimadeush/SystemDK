<?php
/**
 * Project:   SystemDK: PHP Content Management System
 * File:      model_admin_test.class.php
 *
 * @link      http://www.systemsdk.com/
 * @copyright 2013 SystemDK
 * @author    Dmitriy Kravtsov <admin@systemsdk.com>
 * @package   SystemDK
 * @version   3.0
 */
class admin_test extends model_base {


    public function index() {
        $this->registry->main_class->configLoad($this->registry->language."/systemadmin/modules/test/test.conf"); // load conf language file
        $sql = "select news_id, news_title FROM ".PREFIX."_news_".$this->registry->sitelang." where news_status='1' order by news_id";
        $result = $this->db->Execute($sql);
        if($result) {
            if(isset($result->fields['0'])) {
                $numrows = intval($result->fields['0']); //checking if exist news_id, news_id couldn't be empty (as primary key). If exist then numrows>0
            } else {
                $numrows = 0;
            }
        }
        if(isset($numrows) and $numrows > 0) {
            while(!$result->EOF) {
                $news_id = intval($result->fields['0']);
                $news_title = $this->registry->main_class->format_htmlspecchars($this->registry->main_class->extracting_data(trim($result->fields['1']))); // equal to htmlspecialchars(stripslashes(trim($result->fields['1'])));
                $test_news_all[] = array("news_id" => $news_id,"news_title" => $news_title);
                $result->MoveNext();
            }
            $this->registry->main_class->assign("test_news_all",$test_news_all);
        } else {
            $this->registry->main_class->display_theme_adminheader(); // obligatory function 1 - site_charser, site_language, etc...
            $this->registry->main_class->display_theme_adminmain(); // obligatory function 2 - include_header, include_footer
            $this->registry->main_class->displayadmininfo(); // obligatory function 3 - info about administartor which is log-in
            if(!$this->registry->main_class->isCached("systemadmin/main.html","systemadmin|modules|test|error|nonews|".$this->registry->language)) { // checking if cache is not exist
                $this->registry->main_class->assign("test_news_all","nonews");
                //$this->registry->main_class->set_sitemeta($meta_title,$meta_description,$meta_keywords); // You can set meta tags
                $this->registry->main_class->assign("include_center_up","systemadmin/adminup.html"); // this template should be assign before using template for module
                $this->registry->main_class->assign("include_center","systemadmin/modules/test/admintest.html"); // template for module should be display in center column, templatate in center column in this module is systemadmin/modules/test/admintest.html
            }
            $this->registry->main_class->database_close(); // close connection if non-persistant and display statistics in footer
            $this->registry->main_class->display("systemadmin/main.html","systemadmin|modules|test|error|nonews|".$this->registry->language); // template group should be like "systemadmin|modules|modulename|..."
            exit();
        }
        $this->registry->main_class->display_theme_adminheader(); // obligatory function 1 - site_charser, site_language, etc...
        $this->registry->main_class->display_theme_adminmain(); // obligatory function 2 - include_header, include_footer
        $this->registry->main_class->displayadmininfo(); // obligatory function 3 - info about administartor which is log-in
        //$this->registry->main_class->set_sitemeta($meta_title,$meta_description,$meta_keywords); // You can set meta tags
        $this->registry->main_class->assign("include_center_up","systemadmin/adminup.html"); // this template should be assign before using template for module
        $this->registry->main_class->assign("include_center","systemadmin/modules/test/admintest.html"); // template for module should be display in center column, templatate in center column in this module is systemadmin/modules/test/admintest.html
        $this->registry->main_class->database_close(); // close connection if non-persistant and display statistics in footer
        $this->registry->main_class->display("systemadmin/main.html","systemadmin|modules|test|step1|".$this->registry->language); // template group should be like "systemadmin|modules|modulename|..."
    }


    public function step2() {
        if(isset($_GET['test_test_id'])) {
            $test_test_id = intval($_GET['test_test_id']);
        }
        if(!isset($test_test_id) or $test_test_id == 0) {
            $this->registry->main_class->display_theme_adminheader(); // obligatory function 1 - site_charser, site_language, etc...
            $this->registry->main_class->display_theme_adminmain(); // obligatory function 2 - include_header, include_footer
            $this->registry->main_class->displayadmininfo(); // obligatory function 3 - info about administartor which is log-in
            if(!$this->registry->main_class->isCached("systemadmin/main.html","systemadmin|modules|test|error|notselect|".$this->registry->language)) { // checking if cache is not exist
                $this->registry->main_class->configLoad($this->registry->language."/systemadmin/modules/test/test.conf"); // load conf language file
                //$this->registry->main_class->set_sitemeta($meta_title,$meta_description,$meta_keywords); // You can set meta tags
                $this->registry->main_class->assign("test_news_all","notselectnews");
                $this->registry->main_class->assign("include_center_up","systemadmin/adminup.html"); // this template should be assign before using template for module
                $this->registry->main_class->assign("include_center","systemadmin/modules/test/admintest.html"); // template for module should be display in center column, templatate in center column in this module is systemadmin/modules/test/admintest.html
            }
            $this->registry->main_class->database_close(); // close connection if non-persistant and display statistics in footer
            $this->registry->main_class->display("systemadmin/main.html","systemadmin|modules|test|error|notselect|".$this->registry->language); // template group should be like "systemadmin|modules|modulename|..."
            exit();
        }
        $this->registry->main_class->display_theme_adminheader(); // obligatory function 1 - site_charser, site_language, etc...
        $this->registry->main_class->display_theme_adminmain(); // obligatory function 2 - include_header, include_footer
        $this->registry->main_class->displayadmininfo(); // obligatory function 3 - info about administartor which is log-in
        if(!$this->registry->main_class->isCached("systemadmin/main.html","systemadmin|modules|test|step2|".$test_test_id."|".$this->registry->language)) { // checking if cache is not exist
            $sql = "select news_id, news_content FROM ".PREFIX."_news_".$this->registry->sitelang." where news_id='".$test_test_id."' and news_status='1'";
            $result = $this->db->Execute($sql);
            if($result) {
                if(isset($result->fields['0'])) {
                    $numrows = intval($result->fields['0']); //checking if exist news_id, news_id couldn't be 0 (as primary key). If exist then numrows>0
                } else {
                    $numrows = 0;
                }
            }
            if(isset($numrows) and $numrows > 0) {
                $news_id = intval($result->fields['0']);
                $test_news_all = $this->registry->main_class->extracting_data(trim($result->fields['1'])); // equal to stripslashes(trim($result->fields['1']));
                $this->registry->main_class->assign("test_news_all","show");
                $this->registry->main_class->assign("test_news_content",$test_news_all);
            } else {
                if(!$this->registry->main_class->isCached("systemadmin/main.html","systemadmin|modules|test|error|notfind|".$this->registry->language)) { // checking if cache is not exist
                    $this->registry->main_class->configLoad($this->registry->language."/systemadmin/modules/test/test.conf"); // load conf language file
                    //$this->registry->main_class->set_sitemeta($meta_title,$meta_description,$meta_keywords); // You can set meta tags
                    $this->registry->main_class->assign("test_news_all","notfindnews");
                    $this->registry->main_class->assign("include_center_up","systemadmin/adminup.html"); // this template should be assign before using template for module
                    $this->registry->main_class->assign("include_center","systemadmin/modules/test/admintest.html"); // template for module should be display in center column, templatate in center column in this module is  systemadmin/modules/test/admintest.html
                }
                $this->registry->main_class->database_close(); // close connection if non-persistant and display statistics in footer
                $this->registry->main_class->display("systemadmin/main.html","systemadmin|modules|test|error|notfind|".$this->registry->language); // template group should be like "systemadmin|modules|modulename|..."
                exit();
            }
            $this->registry->main_class->configLoad($this->registry->language."/systemadmin/modules/test/test.conf"); // load conf language file
            //$this->registry->main_class->set_sitemeta($meta_title,$meta_description,$meta_keywords); // You can set meta tags
            $this->registry->main_class->assign("include_center_up","systemadmin/adminup.html"); // this template should be assign before using template for module
            $this->registry->main_class->assign("include_center","systemadmin/modules/test/admintest.html"); // template for module should be display in center column, templatate in center column in this module is  systemadmin/modules/test/admintest.html
        }
        $this->registry->main_class->database_close(); // close connection if non-persistant and display statistics in footer
        $this->registry->main_class->display("systemadmin/main.html","systemadmin|modules|test|step2|".$test_test_id."|".$this->registry->language); // template group should be like "systemadmin|modules|modulename|..."
    }
}

?>