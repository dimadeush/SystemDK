<?php


/**
 * Project:   SystemDK: PHP Content Management System
 * File:      controller_admin_test.class.php
 *
 * @link      http://www.systemsdk.com/
 * @copyright 2014 SystemDK
 * @author    Dmitriy Kravtsov <admin@systemsdk.com>
 * @package   SystemDK
 * @version   3.1
 */
class controller_admin_test extends controller_base {


    private $model_admin_test;


    public function __construct($registry) {
        parent::__construct($registry);
        $this->model_admin_test = singleton::getinstance('admin_test',$registry);
    }


    private function test_view($type,$title,$cache_category = false,$cache = false,$template = false) {
        $this->registry->controller_theme->display_theme_adminheader(); // obligatory function 1 - site_charset, site_language, etc...
        $this->registry->controller_theme->display_theme_adminmain(); // obligatory function 2 - include_header, include_footer
        $this->registry->main_class->assign_admin_info(); // obligatory function 3 - info about administrator which is log-in
        if(empty($cache_category)) {
            $cache_category = 'modules|test|error';
        }
        if(empty($template)) {
            $template = 'admintest.html';
        }
        if(empty($cache)) {
            $cache = $type;
        }
        if(!$this->isCached("systemadmin/main.html",$this->registry->sitelang."|systemadmin|".$cache_category."|".$cache."|".$this->registry->language)) { // checking if cache is not exist
            $this->configLoad($this->registry->language."/systemadmin/modules/test/test.conf"); // load conf language file
            $this->registry->main_class->set_sitemeta($this->getConfigVars($title)); // You can set meta tags
            $this->assign("include_center_up","systemadmin/adminup.html"); // this template should be assign before using template for module
            $this->assign("include_center","systemadmin/modules/test/".$template); // template for module should be display in center column, templatate in center column in this module is systemadmin/modules/test/admintest.html
        }
        $this->display("systemadmin/main.html",$this->registry->sitelang."|systemadmin|".$cache_category."|".$cache."|".$this->registry->language); // template group should be like "systemadmin|modules|modulename|..."
        exit();
    }


    public function index() {
        $type = false;
        $title = '_MODULE_TEST_TITLE';
        $cache_category = 'modules|test';
        $cache = 'step1';
        $this->model_admin_test->index();
        $error = $this->model_admin_test->get_property_value('error');
        $result = $this->model_admin_test->get_property_value('result');
        $this->assign_array($result);
        if($error === 'nonews') {
            $this->test_view($error,$title);
        }
        $this->test_view($type,$title,$cache_category,$cache);
    }


    public function step2() {
        $test_test_id = 0;
        if(isset($_GET['test_test_id'])) {
            $test_test_id = intval($_GET['test_test_id']);
        }
        $type = false;
        $title = false;
        $cache_category = 'modules|test|step2';
        $cache = $test_test_id;
        $this->model_admin_test->step2($test_test_id);
        $error = $this->model_admin_test->get_property_value('error');
        $result = $this->model_admin_test->get_property_value('result');
        $this->assign_array($result);
        if($error === 'notselectnews' or $error === 'notfindnews') {
            $title = '_MODULE_TEST_TITLE';
            $this->test_view($error,$title);
        }
        $this->test_view($type,$title,$cache_category,$cache);
    }
}