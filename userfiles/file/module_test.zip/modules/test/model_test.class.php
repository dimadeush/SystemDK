<?php


/**
 * Project:   SystemDK: PHP Content Management System
 * File:      model_news.class.php
 *
 * @link      http://www.systemsdk.com/
 * @copyright 2014 SystemDK
 * @author    Dmitriy Kravtsov <admin@systemsdk.com>
 * @package   SystemDK
 * @version   3.1
 */
class test extends model_base {


    private $error;
    private $error_array;
    private $result;
    private $module_test_param1;


    public function __construct($registry) {
        parent::__construct($registry);
        require_once('test_config.inc');
        $this->module_test_param1 = MODULE_TEST_PARAM1;
    }


    public function get_property_value($property) {
        if(isset($this->$property) and in_array($property,array('error','error_array','result'))) {
            return $this->$property;
        }
        return false;
    }


    public function index() {
        $this->result = false;
        $this->error = false;
        $this->error_array = false;
        $sql = "select news_id, news_title FROM ".PREFIX."_news_".$this->registry->sitelang." where news_status='1' order by news_id";
        $result = $this->db->Execute($sql);
        $row_exist = 0;
        if($result) {
            if(isset($result->fields['0'])) {
                $row_exist = intval($result->fields['0']); //checking if exist news_id, news_id couldn't be empty (as primary key).
            }
        }
        if($row_exist < 1) {
            $this->error = 'nonews';
            $this->result['test_news_all'] = $this->error;
            return;
        }
        while(!$result->EOF) {
            $news_id = intval($result->fields['0']);
            $news_title = $this->registry->main_class->format_htmlspecchars($this->registry->main_class->extracting_data($result->fields['1'])); // equal to htmlspecialchars(stripslashes(trim($result->fields['1'])));
            $test_news_all[] = array("news_id" => $news_id,"news_title" => $news_title);
            $result->MoveNext();
        }
        $this->result['test_news_all'] = $test_news_all;
    }


    public function read($test_test_id) {
        $this->result = false;
        $this->error = false;
        $this->error_array = false;
        $test_test_id = intval($test_test_id);
        if($test_test_id < 1) {
            $this->error = 'notselectnews';
            $this->result['test_news_all'] = $this->error;
            return;
        }
        $sql = "select news_id, news_content, news_meta_title, news_meta_keywords, news_meta_description FROM ".PREFIX."_news_".$this->registry->sitelang." where news_id='".$test_test_id."' and news_status='1'";
        $result = $this->db->Execute($sql);
        $row_exist = 0;
        if($result) {
            if(isset($result->fields['0'])) {
                $row_exist = intval($result->fields['0']); //checking if exist news_id, news_id couldn't be empty (as primary key).
            }
        }
        if($row_exist < 1) {
            $this->error = 'notfindnews';
            $this->result['test_news_all'] = $this->error;
            return;
        }
        $test_news_all = $this->registry->main_class->extracting_data(trim($result->fields['1'])); // equal to stripslashes(trim($result->fields['1']));
        $news_meta_title = $this->registry->main_class->extracting_data(trim($result->fields['2']));
        $news_meta_keywords = $this->registry->main_class->extracting_data(trim($result->fields['3']));
        $news_meta_description = $this->registry->main_class->extracting_data(trim($result->fields['4']));
        $this->result['test_news_all'] = "show";
        $this->result['test_news_content'] = $test_news_all;
        $this->registry->main_class->set_sitemeta($news_meta_title,$news_meta_description,$news_meta_keywords); // You can set meta tags
    }
}