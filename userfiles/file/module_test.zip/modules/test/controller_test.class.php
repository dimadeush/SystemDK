<?php


/**
 * Project:   SystemDK: PHP Content Management System
 * File:      controller_test.class.php
 *
 * @link      http://www.systemsdk.com/
 * @copyright 2014 SystemDK
 * @author    Dmitriy Kravtsov <admin@systemsdk.com>
 * @package   SystemDK
 * @version   3.1
 */
class controller_test extends controller_base {


    private $model_test;


    public function __construct($registry) {
        parent::__construct($registry);
        $this->model_test = singleton::getinstance('test',$registry);
    }


    private function test_view($type,$title,$cache_category = false,$cache = false,$template) {
        if(empty($cache_category)) {
            $cache_category = 'modules|test|error';
        }
        if(empty($cache)) {
            $cache = $type;
        }
        if(!$this->isCached("index.html",$this->registry->sitelang."|".$cache_category."|".$cache."|".$this->registry->language)) { // checking if cache is not exist
            $this->configLoad($this->registry->language."/modules/test/test.conf"); // load conf language file
            if(!empty($title)) {
                $this->registry->main_class->set_sitemeta($this->getConfigVars($title)); // You can set meta tags
            }
        }
        $this->assign("include_center","modules/test/".$template); // template for module should be display in center column, template in center column in this module is modules/test/test.html
        $this->display("index.html",$this->registry->sitelang."|".$cache_category."|".$cache."|".$this->registry->language); // template group should be like "ru|modules|modulename|..."
        exit();
    }


    public function index() {
        $type = false;
        $title = '_MODULETESTTITLE';
        $cache_category = 'modules|test';
        $cache = 'step1';
        $template = 'test.html';
        $this->model_test->index();
        $error = $this->model_test->get_property_value('error');
        $result = $this->model_test->get_property_value('result');
        $this->assign_array($result); // assign all necessary parameters to smarty
        if($error === 'nonews') {
            $cache_category = false;
            $cache = $error;
            $this->test_view($type,$title,$cache_category,$cache,$template); // display error and exit
        }
        $this->test_view($type,$title,$cache_category,$cache,$template); // display data and exit
    }


    public function read() {
        if(isset($_GET['test_test_id'])) {
            $test_test_id = intval($_GET['test_test_id']);
        } else {
            $test_test_id = 0;
        }
        $type = false;
        $title = false;
        $cache_category = 'modules|test|step2';
        $cache = $test_test_id;
        $template = 'test.html';
        if(!$this->isCached("index.html",$this->registry->sitelang."|".$cache_category."|".$cache."|".$this->registry->language)) { // checking if cache is not exist
            $this->model_test->read($test_test_id);
            $error = $this->model_test->get_property_value('error');
            $result = $this->model_test->get_property_value('result');
            $this->assign_array($result); // assign all necessary parameters to smarty
            if($error === 'notselectnews' or $error === 'notfindnews') {
                $title = '_MODULETESTTITLE';
                $cache_category = false;
                $cache = $error;
                $this->test_view($type,$title,$cache_category,$cache,$template); // display error and exit
            }
        }
        $this->test_view($type,$title,$cache_category,$cache,$template); // display data and exit
    }
}